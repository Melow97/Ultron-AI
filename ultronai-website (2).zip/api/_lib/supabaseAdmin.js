// Server-only Supabase client using the service_role key, which bypasses
// Row Level Security entirely. That's exactly what the webhook needs (it
// has to update ANY user's plan, not just "its own"), but it's also why
// this file must never be imported into frontend code and why the key it
// uses (SUPABASE_SERVICE_ROLE_KEY, no VITE_ prefix) is never bundled into
// the browser build — only Vite-prefixed vars get exposed client-side.
//
// Files under api/_lib are not turned into public routes by Vercel
// (the underscore prefix opts them out), so this stays a private helper.

import { createClient } from "@supabase/supabase-js";

export function getSupabaseAdmin() {
  const url = process.env.VITE_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) return null;
  return createClient(url, serviceKey, { auth: { persistSession: false } });
}
