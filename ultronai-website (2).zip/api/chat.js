// This file lives in /api, which Vercel automatically turns into a
// serverless backend endpoint at yoursite.com/api/chat — no server to manage.
//
// Your ANTHROPIC_API_KEY never reaches the browser. The frontend calls
// this endpoint, this endpoint calls Anthropic with the real key, and
// only the response comes back to the browser.

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    res.status(500).json({
      error: "ANTHROPIC_API_KEY is not set. Add it in your Vercel project's Settings > Environment Variables, then redeploy.",
    });
    return;
  }

  try {
    const { model, max_tokens, system, messages, tools } = req.body || {};

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: model || "claude-sonnet-4-6",
        max_tokens: max_tokens || 1200,
        system,
        messages,
        ...(tools ? { tools } : {}),
      }),
    });

    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    res.status(500).json({ error: "Server error contacting the model." });
  }
}
