-- Run this once in your Supabase project: Dashboard > SQL Editor > New query > paste > Run.
--
-- This creates the one table this whole feature depends on: a "profiles"
-- row per user, holding what plan they're on. Supabase's built-in auth
-- already handles sign-up/sign-in/sessions (that's the auth.users table
-- referenced below) — this just adds the one column your product actually
-- cares about: plan.

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  plan text not null default 'free',
  stripe_customer_id text,
  updated_at timestamptz not null default now()
);

alter table profiles enable row level security;

-- Users can see and update only their own row — never someone else's.
create policy "Users can view their own profile"
  on profiles for select
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on profiles for update
  using (auth.uid() = id);

-- Whenever someone signs up, automatically give them a profile row
-- (defaults to plan = 'free'). Without this, a new user would have no
-- profile row at all until something manually created one.
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
