// This is the Fly.io equivalent of the api/ folder. Fly runs a persistent
// container, not on-demand functions, so instead of separate files per
// route, this is one small Express server with three routes doing the
// same thing chat.js / create-checkout-session.js / webhook.js did on
// Vercel — plus it serves the built frontend itself.

import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 8080;

function getSupabaseAdmin() {
  const url = process.env.VITE_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) return null;
  return createClient(url, serviceKey, { auth: { persistSession: false } });
}

/* ---------- Stripe webhook ----------
   Registered BEFORE express.json() on purpose — Stripe needs the raw,
   unparsed request body to verify the signature. Once express.json() runs
   on a route, the raw body is gone. */
app.post("/api/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  const secretKey = process.env.STRIPE_SECRET_KEY;
  if (!webhookSecret || !secretKey) {
    res.status(500).send("Stripe webhook isn't configured (missing STRIPE_WEBHOOK_SECRET or STRIPE_SECRET_KEY).");
    return;
  }

  const stripe = new Stripe(secretKey);
  const sig = req.headers["stripe-signature"];

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    res.status(400).send(`Webhook signature verification failed: ${err.message}`);
    return;
  }

  const supabaseAdmin = getSupabaseAdmin();

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object;
      const userId = session.client_reference_id;
      if (supabaseAdmin && userId) {
        const { error } = await supabaseAdmin
          .from("profiles")
          .update({ plan: "pro", stripe_customer_id: session.customer, updated_at: new Date().toISOString() })
          .eq("id", userId);
        if (error) console.error("Failed to mark user as Pro:", error.message);
      } else {
        console.warn("checkout.session.completed with no userId or no database configured — nothing updated.");
      }
      break;
    }
    case "customer.subscription.deleted": {
      const subscription = event.data.object;
      if (supabaseAdmin) {
        const { error } = await supabaseAdmin
          .from("profiles")
          .update({ plan: "free", updated_at: new Date().toISOString() })
          .eq("stripe_customer_id", subscription.customer);
        if (error) console.error("Failed to downgrade user:", error.message);
      }
      break;
    }
    case "invoice.payment_failed": {
      console.log("Payment failed for customer:", event.data.object.customer);
      break;
    }
    default:
      break;
  }

  res.status(200).json({ received: true });
});

// Everything below this line gets normal JSON body parsing.
app.use(express.json());

app.post("/api/chat", async (req, res) => {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: "ANTHROPIC_API_KEY is not set. Run: fly secrets set ANTHROPIC_API_KEY=..." });
    return;
  }
  try {
    const { model, max_tokens, system, messages, tools } = req.body || {};
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: model || "claude-sonnet-4-6",
        max_tokens: max_tokens || 1200,
        system,
        messages,
        ...(tools ? { tools } : {}),
      }),
    });
    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    res.status(500).json({ error: "Server error contacting the model." });
  }
});

app.post("/api/create-checkout-session", async (req, res) => {
  const secretKey = process.env.STRIPE_SECRET_KEY;
  const priceId = process.env.STRIPE_PRICE_ID_PRO;
  if (!secretKey || !priceId) {
    res.status(500).json({ error: "Stripe isn't configured yet. Run: fly secrets set STRIPE_SECRET_KEY=... STRIPE_PRICE_ID_PRO=..." });
    return;
  }
  const { userId, email } = req.body || {};
  if (!userId) {
    res.status(401).json({ error: "You need to be signed in to upgrade — no user ID was provided." });
    return;
  }

  const stripe = new Stripe(secretKey);
  const origin = req.headers.origin || `https://${req.headers.host}`;

  try {
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${origin}/?checkout=success`,
      cancel_url: `${origin}/?checkout=cancelled`,
      allow_promotion_codes: true,
      client_reference_id: userId,
      customer_email: email || undefined,
    });
    res.status(200).json({ url: session.url });
  } catch (err) {
    res.status(500).json({ error: err.message || "Couldn't start checkout." });
  }
});

/* ---------- serve the built frontend ---------- */
app.use(express.static(path.join(__dirname, "dist")));
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "dist", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`UltronAI running on port ${PORT}`);
});
